const no = document.getElementById("no");
const yes = document.getElementById("yes");

let noScale = 1;
let yesScale = 1;

no.onclick = function () {

    no.style.position = "fixed";
    no.style.left = Math.random() * (window.innerWidth - 120) + "px";
    no.style.top = Math.random() * (window.innerHeight - 60) + "px";

    if (noScale > 0.3) {
        noScale -= 0.12;
        no.style.transform = "scale(" + noScale + ")";
    }

    yesScale += 0.12;
    yes.style.transform = "scale(" + yesScale + ")";
};