<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Snake</title>
<style>
body{
margin:0;
background:#222;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}
canvas{
background:#000;
border:3px solid #0f0;
}
</style>
</head>
<body>

<canvas id="game" width="400" height="400"></canvas>

<script>
const c=document.getElementById("game");
const ctx=c.getContext("2d");

let snake=[{x:200,y:200}];
let food={x:100,y:100};
let dx=20,dy=0;

document.onkeydown=e=>{
if(e.key=="ArrowUp"){dx=0;dy=-20;}
if(e.key=="ArrowDown"){dx=0;dy=20;}
if(e.key=="ArrowLeft"){dx=-20;dy=0;}
if(e.key=="ArrowRight"){dx=20;dy=0;}
}

function draw(){

ctx.clearRect(0,0,400,400);

ctx.fillStyle="red";
ctx.fillRect(food.x,food.y,20,20);

ctx.fillStyle="lime";
snake.forEach(s=>ctx.fillRect(s.x,s.y,20,20));

let head={
x:snake[0].x+dx,
y:snake[0].y+dy
};

if(head.x==food.x&&head.y==food.y){
food={
x:Math.floor(Math.random()*20)*20,
y:Math.floor(Math.random()*20)*20
};
}else{
snake.pop();
}

if(head.x<0||head.x>=400||head.y<0||head.y>=400){
alert("Game Over");
location.reload();
}

snake.unshift(head);
}

setInterval(draw,150);
</script>

</body>
</html>